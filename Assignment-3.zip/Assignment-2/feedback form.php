<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
  background-color:powderblue;
}
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #45a049;
}
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
h1{
  text-align: center;
  color: red; /* Add red color to the h1 heading */
}
.star-rating {
  display: flex;
  flex-direction: row-reverse;
  justify-content: flex-end;
}

.radio-input {
  position: fixed;
  opacity: 0;
  pointer-events: none;
}

.radio-label {
  cursor: pointer;
  font-size: 0;
  color: rgba(0,0,0,0.2);
  transition: color 0.1s ease-in-out;
}

.radio-label:before {
  content: "★";
  display: inline-block;
  font-size: 32px;
}

.radio-input:checked ~ .radio-label {
  color: #ffc700;
  color: gold;
}

.radio-label:hover,
.radio-label:hover ~ .radio-label {
  color: goldenrod;
}

.radio-input:checked + .radio-label:hover,
.radio-input:checked + .radio-label:hover ~ .radio-label,
.radio-input:checked ~ .radio-label:hover,
.radio-input:checked ~ .radio-label:hover ~ .radio-label,
.radio-label:hover ~ .radio-input:checked ~ .radio-label {
  color: darkgoldenrod;
}

.average-rating {
  position: relative;
  appearance: none;
  color: transparent;
  width: auto;
  display: inline-block;
  vertical-align: baseline;
  font-size: 25px;
}

.average-rating::before {
  --percent: calc(4.3/5*100%);
  content: '★★★★★';
  position: absolute;
  top: 0;
  left: 0;
  color: rgba(0,0,0,0.2);
  background: linear-gradient(90deg, gold var(--percent), rgba(0,0,0,0.2) var(--percent));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>
</head>
<body>
<h1>College Feedback Form</h1>
<div class="container">
  <form method="post" action="connect.php">
    <label for="fname">Student Name</label>
    <input type="text" id="student_name" name="student_name" placeholder="Your name..">
    <label for="lname">Enrollment No:</label>
    <input type="text" id="enrollment_no" name="enrollment_no" placeholder="Your enrollment no..">
    <label for="College">College</label>
    <select id="college" name="college">
      <option value="SOCET">SOCET</option>
      <option value="ASOIT">ASOIT</option>
    </select>
    <label for="Department">Department</label>
    <select id="department" name="department">
      <option value="CE">CE</option>
      <option value="IT">IT</option>
      <option value="Mech">Mech</option>
      <option value="Civil">Civil</option>
      <option value="electrical">electrical</option>
      <option value="ICT">ICT</option>
    </select>
    <label for="Give your feedback">Give your feedback</label>
    <textarea id="feedback" name="feedback" placeholder="Write something.." style="height:200px"></textarea>

    <div class="star-rating">
      <input type="radio" id="star5" name="rating" value="5" class="radio-input">
      <label for="star5" class="radio-label"></label>
      <input type="radio" id="star4" name="rating" value="4" class="radio-input">
      <label for="star4" class="radio-label"></label>
      <input type="radio" id="star3" name="rating" value="3" class="radio-input">
      <label for="star3" class="radio-label"></label>
      <input type="radio" id="star2" name="rating" value="2" class="radio-input">
      <label for="star2" class="radio-label"></label>
      <input type="radio" id="star1" name="rating" value="1" class="radio-input">
      <label for="star1" class="radio-label"></label>
    </div>

    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
