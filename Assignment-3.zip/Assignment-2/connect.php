<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = filter_input(INPUT_POST, 'student_name');
    $lastName = filter_input(INPUT_POST, 'enrollment_no');
    $college = filter_input(INPUT_POST, 'college');
    $department = filter_input(INPUT_POST, 'department');
    $feedback = filter_input(INPUT_POST, 'feedback');
    $rating = filter_input(INPUT_POST, 'rating');

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'feedback details');
    if ($conn->connect_error) {
        echo "Connection Failed: " . $conn->connect_error;
        die();
    } else {
        $stmt = $conn->prepare("INSERT INTO `form_details` (`firstName`, `lastName`, `College`, `Department`, `Feedback`, `Rating`) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            echo "Prepare failed: " . $conn->error;
            die();
        }

        $stmt->bind_param("sssssi", $firstName, $lastName, $college, $department, $feedback, $rating);
        if ($stmt->execute()) {
            echo "Data submitted successfully...";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>
